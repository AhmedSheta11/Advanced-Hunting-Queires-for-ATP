# Detect malicious documents associated with group known as "OceanLotus"

This query was originally published in a threat analytics report about the group known to other security researchers as *APT32* or *OceanLotus*

This tracked activity group uses a wide array of malicious documents to conduct attacks. Some of their favorite techniques include sideloading dynamic link libraries,  and disguising payloads as image files. The group has weaponized files with exploits for the following vulnerabilities:

* [CVE-2017-11882](https://nvd.nist.gov/vuln/detail/CVE-2017-11882) - [Software update](https://portal.msrc.microsoft.com/en-US/security-guidance/advisory/CVE-2017-11882)
* [CVE-2017-0199](https://nvd.nist.gov/vuln/detail/CVE-2017-0199) - [Software update](https://portal.msrc.microsoft.com/en-US/security-guidance/advisory/CVE-2017-0199)

The following query detects known malicious files associated with the group's campaigns.

See [Detect malicious network activity associated with group known as "OceanLotus"](oceanlotus-apt32-network.md) for another query related to this group's activity.

## Query

```Kusto
let MaliciousFiles=pack_array(//'KerrDown Lure Documents',
'b32b5f76e7386a65bd9220befb21e0c46d4084c4',
'c9d6b6fa37ca3d8cb57248993bb7c8a8fcd1bc89',
'bf127e2a526240c7e65f24c544dad820cebe6d88',
'347f555857d56a5afd33cfa19f8b5c771eed2553',
'26c86c777fc074f5bbad27084bcb3bbc7afff88e',
'872d2f4ccc43c08f73e84647b3098ff044cdfb75',
'fb20427d0ac3cd4542755168886a96bde04c4f81',
//'KerrDown Malware Downloader',
'5f42b1771ce97679df78713292838c830e606e48',
'72571ea4389af7a3a0e04d87327427d199f1d178',
'3f2a7b5605262d8aa189c32a049756c6bfed589b',
'220ea47d692afc196b5b913a9693323fd51f00f5',
'85021e711d5c7d5bd968f6dfed7102ab4d8828e8',
'c9e101c77f67203dfef66d21f2fa6c8765a6c649',
'3182141a8255baa5b82c0953dd4541c6f9f26a03',
'2d92d6459ef83ddf006bff4046b1bab86161a26b',
'6aef7916f1c5d1886db06fe2d4bf35614a0b921f',
'edd306617f1c7390a6bc067d3e8dfb44ac57287c',
'd8cd8068cb30605646258c7a0d9b47e00eac28c5',
'36422fe35473cc28a14701e5d9dcff4c2426d0ae',
//'OceanLotus Documents Exploiting CVE-2017-11882',
'd1357b284c951470066aaa7a8228190b88a5c7c3',
'49dff13500116b6c085c5ce3de3c233c28669678',
'9df3f0d8525edf2b88c4a150134c7699a85a1508',
'50a755b30e8f3646f9476080f2c3ae1347f8f556',
'bb060e5e7f7e946613a3497d58fbf026ae7c369a',
'e2d949cf06842b5f7ae6b2dffaa49771a93a00d9',
'OceanLotus Malicious SFX Files',
'ac10f5b1d5ecab22b7b418d6e98fa18e32bbdeab',
'cd13210a142da4bc02da47455eb2cfe13f35804a',
'b4e6ddcd78884f64825fdf4710b35cdbeaabe8e2',
'cc918f0da51794f0174437d336e6f3edfdd3cbe4',
'8b991d4f2c108fd572c9c2059685fc574591e0be',
'3dfc3d81572e16ceaae3d07922255eb88068b91d',
//'OceanLotus OCX Dropper Files',
'efac23b0e6395b1178bcf7086f72344b24c04dcc',
'7642f2181cb189965c596964d2edf8fe50da742b',
'377fdc842d4a721a103c32ce8cb4daf50b49f303',
'bd39591a02b4e403a25aae502648264308085ded',
'b998f1b92ed6246ded13b79d069aa91c35637dec',
'83d520e8c3fdaefb5c8b180187b45c65590db21a',
'b744878e150a2c254c867bad610778852c66d50a',
'77c42f66dadf5b579f6bcd0771030adc7aefa97c',
//'Malicious PNG Loader Files Used By OceanLotus ',
'b58b7e8361e15fdc9fb21d0f7c26d5fc17241ff7',
'5d5c1297415cc5746559182d91c9114700be07e2',
'43191e81e1dcc9fac138fc1cc5e3aeb9b25cc1f4',
//'Malicious DLL Files Used By OceanLotus ',
'fa6be68b59b204c9f5ae886a888627a190491cf7',
'20c3a72ff476aa1fb71367e1d5dd6e0eb166167e',
'9d39e11f48b3ed4df35f5e19dd00b47764c98bdd',
'81c1aff8589dc1e556f68562d7154377c745a1d5',
'eb27eb72c4709d77db260b942d87ed486e271c93',
'a28095221fbaad64af7a098e3dda80f6f426b1c2',
'dabefa810a4febf4e7178df9d2ca2576333e04f2',
'e716a98a4f0ebd366ff29bd9164e81e7c39a7789',
'89abb3d70f200d480f05162c6877fab64941c5dd',
//'OceanLotus Documents Exploiting CVE-2017-0199',
'928b391af8e029dd8bef4f6dd82223b961429f0d',
'295a99bebb8122a0fc26086ecc115582f37f6b47', 
'8b9fc2281a604a0ef2d56591a79f9f9397a6a2d2', 
'ec34a6b8943c110687ef6f39a838e68d42d24863', 
'd8be4f41886666687caf69533e11193e65e2a8e5', 
'd8be4f41886666687caf69533e11193e65e2a8e5', 
//'Malicious Documents Used By OceanLotus', 
'8b599ecdbec12a5bd76cf290f9297f13e8397d56', 
'c9073998d2a202e944f21e973448062af4fd29c0', 
'91510b97f764296b16fc88f0195cec6e6f1604af', 
'e00a4e0a03655dccff5ffdb4f4540115d820b5bb', 
'd39a7ecf844545363b96b8ee2eda9b76d51d602b', 
//'JEShell Malware Downloader', 
'8cad6621901b5512f4ecab7a22f8fcc205d3762b', 
'668572ba2aff5374a3536075b01854678c392c04'); 
union DeviceFileEvents, DeviceProcessEvents 
| where Timestamp > ago(14d) 
| where SHA1 in(MaliciousFiles) or SHA1 in(MaliciousFiles)
```

## Category

This query can be used to detect the following attack techniques and tactics ([see MITRE ATT&CK framework](https://attack.mitre.org/)) or security configuration states.

| Technique, tactic, or state | Covered? (v=yes) | Notes |
|-|-|-|
| Initial access |  |  |
| Execution | v |  |
| Persistence | v |  |
| Privilege escalation |  |  |
| Defense evasion | v |  |
| Credential Access |  |  |
| Discovery | v |  |
| Lateral movement |  |  |
| Collection |  |  |
| Command and control |  |  |
| Exfiltration |  |  |
| Impact |  |  |
| Vulnerability |  |  |
| Misconfiguration |  |  |
| Malware, component | v |  |

## Contributor info

**Contributor:** Microsoft Threat Protection team