# FireEye Red Team tool HASHs [Nobelium]

This query searches for the HASHs of the FireEye Red Team tools compromised by the Nobelium activity group.

See [all-hashes.csv](https://github.com/fireeye/red_team_tool_countermeasures/blob/master/all-hashes.csv) on the [official FireEye repo](https://github.com/fireeye).

## Query

```Kusto
let MD5Hash= dynamic(
    [
'013c7708f1343d684e3571453261b586',
'01d68343ac46db6065f888a094edfe4f',
'04eb45f8546e052fe348fda2425b058c',
'05b99d438dac63a5a993cea37c036673',
'09bdbad8358b04994e2c04bb26a160ef',
'0a86d64c3b25aa45428e94b6e0be3e08',
'0b1e512afe24c31531d6db6b47bac8ee',
'100d73b35f23b2fe84bf7cd37140bf4d',
'11b5aceb428c3e8c61ed24a8ca50553e',
'12c3566761495b8353f67298f15b882c',
'150224a0ccabce79f963795bf29ec75b',
'152fc2320790aa16ef9b6126f47c3cca',
'226b1ac427eb5a4dc2a00cc72c163214',
'2398ed2d5b830d226af26dedaf30f64a',
'24a7c99da9eef1c58f09cf09b9744d7b',
'25a97f6dba87ef9906a62c1a305ee1dd',
'294b1e229c3b1efce29b162e7b3be0ab',
'2b686a8b83f8e1d8b455976ae70dab6e',
'2e67c62bd0307c04af469ee8dcb220f2',
'3322fba40c4de7e3de0fda1123b0bf5d',
'3651f252d53d2f46040652788499d65a',
'383161e4deaf7eb2ebeda2c5e9c3204c',
'3b926b5762e13ceec7ac3a61e85c93bb',
'3bb34ebd93b8ab5799f4843e8cc829fa',
'3e61ca5057633459e96897f79970a46d',
'3fb9341fb11eca439b50121c6f7c59c7',
'4022baddfda3858a57c9cbb0d49f6f86',
'4326a7e863928ffbb5f6bdf63bb9126e',
'4410e95de247d7f1ab649aa640ee86fb',
'4414953fa397a41156f6fa4f9462d207',
'4456e52f6f8543c3ba76cb25ea3e9bd2',
'44887551a47ae272d7873a354d24042d',
'45736deb14f3a68e88b038183c23e597',
'4bf96a7040a683bd34c618431e571e26',
'4e7e90c7147ee8aa01275894734f4492',
'4fd62068e591cbd6f413e1c2b8f75442',
'5125979110847d35a338caac6bff2aa8',
'562ecbba043552d59a0f23f61cea0983',
'590d98bb74879b52b97d8a158af912af',
'5e14f77f85fd9a5be46e7f04b8a144f5',
'66cdaa156e4d372cfa3dea0137850d20',
'66e0681a500c726ed52e5ea9423d2654',
'68acf11f5e456744262ff31beae58526',
'6902862bd81da402e7ac70856afbe6a2',
'6a9a114928554c26675884eeb40cc01b',
'6efb58cf54d1bb45c057efcfbbd68a93',
'6f04a93753ae3ae043203437832363c4',
'79259451ff47b864d71fb3f94b1774f3',
'7af24305a409a2b8f83ece27bb0f7900',
'7c2a06ceb29cdb25f24c06f2a8892fba',
'7e6bc0ed11c2532b2ae7060327457812',
'7f8102b789303b7861a03290c79feba0',
'8025bcbe3cc81fc19021ad0fbc11cf9b',
'82773afa0860d668d7fe40e3f22b0f3e',
'82e33011ac34adfcced6cddc8ea56a81',
'83ed748cd94576700268d35666bf3e01',
'848837b83865f3854801be1f25cb9f4d',
'8c91a27bbdbe9fb0877daccd28bd7bb5',
'8d949c34def898f0f32544e43117c057',
'9529c4c9773392893a8a0ab8ce8f8ce1',
'98ecf58d48a3eae43899b45cec0fc6b7',
'995120b35db9d2f36d7d0ae0bfc9c10d',
'9c8eb908b8c1cda46e844c24f65d9370',
'9ccda4d7511009d5572ef2f8597fba4e',
'9dcb6424662941d746576e62712220aa',
'9e85713d615bda23785faf660c1b872c',
'9f401176a9dd18fa2b5b90b4a2aa1356',
'a107850eb20a4bb3cc59dbd6861eaf0f',
'a495c6d11ff3f525915345fb762f8047',
'a8b5dcfea5e87bf0e95176daa243943d',
'a91bf61cc18705be2288a0f6f125068f',
'aeb0e1d0e71ce2a08db9b1e5fb98e0aa',
'b66347ef110e60b064474ae746701d4a',
'b8415b4056c10c15da5bba4826a44ffd',
'c0598321d4ad4cf1219cc4f84bad4094',
'c74ebb6c238bbfaefd5b32d2bf7c7fcc',
'cdf58a48757010d9891c62940c439adb',
'cf752e9cd2eccbda5b8e4c29ab5554b6',
'd0a830403e56ebaa4bfbe87dbfdee44f',
'd5d3d23c8573d999f1c48d3e211b1066',
'd7cfb9fbcf19ce881180f757aeec77dd',
'd93100fe60c342e9e3b13150fd91c7d8',
'db0eaad52465d5a2b86fdd6a6aa869a5',
'dd8805d0e470e59b829d98397507d8c2',
'dfbb1b988c239ade4c23856e42d4127b',
'e0683f8ee787313cfd2c61cd0995a830',
'e4efa759d425e2f26fbc29943a30f5bd',
'e7beece34bdf67cbb8297833c5953669',
'e89efa88e3fda86be48c0cc8f2ef7230',
'e91670423930cbbd3dbf5eac1f1a7cb6',
'ece07daca53dd0a7c23dacabf50f56f1',
'edcd58ba5b1b87705e95089002312281',
'eeedc09570324767a3de8205f66a5295',
'f20824fa6e5c81e3804419f108445368',
'f3dd8aa567a01098a8a610529d892485',
'f41074be5b423afb02a74bc74222e35d',
'f59095f0ab15f26a1ead7eed8cdb4902',
'f7d9961463b5110a3d70ee2e97842ed3',
'fa255fdc88ab656ad9bc383f9b322a76',
'fbefb4074f1672a3c29c1a47595ea261'
    ]
);
let SHA1Hash= dynamic(
    [
'5968670c0345b0ab5404bd84cb60d7af7a625020',
'fb514d59d4beabd97a25c2eefb74ce85b16edaac',
'863514b3c3f88d084bbe27bf7ba59189fbdbd902',
'0c8e807969295237c74a1016c284f99975e761b9',
'226c07a66c530350e9c89ddbe550646e94b5ff96',
'1bfaccc392df6d62fb3d8c9e69b72f0b4c5a478a',
'7bbdbe9f26a3d96e31d648551e66f91a9bd928ab',
'0613d4a7556d13889727e2e3312abfc2f6bbc046',
'c47cf12067a0ddf212a890f26dc8578d8bb705cb',
'9a6e4d1a0b682abc848e5c7a6f8782cb0213fc5c',
'af35d96b1e70d05a0c556bb9fa46af7450db1474',
'f7d483346611ce1d3e5bf8eeebfc7be122a131b9',
'4e1aead0a6c181afbd12c75f8da5a1a01acafc6c',
'8ac4feca574feb39aa887ac24803cc66fc658789',
'ac9db0eb0ef64d4b9fa68f52c713904e6fd4d6e6',
'f142936d2ab1e023ffc39d41a801d18a0c7df398',
'12e46031d953fd0a9a2b0ec573b695420eafd5f2',
'03324510e41c7b9fec35516aca947850d4ef7529',
'5d358567e549a6f8e471697f7c78bc8bdf2a6534',
'33d6eef3c7c5a496cc22acaaa7aed03d59af498a',
'803b1743cb5498543802c14e67a34c61977d73b5',
'4d0c07c7a215ec9d563b0a3e73899e56fcf94566',
'67f7ba6b4c301d372d8fb28cb231fb13a58b1dc9',
'd5adb0dc551c3c97fc929d86e039672b97ddc65e',
'063ede02eb666c16c61135aa27b1a026014cfc77',
'e54f5737847287e49a306f312995c9aba38314d4',
'e74f4f592e17a7c3c9be85b430dddeea2c3abda4',
'ae9d8a3e09b55a45c0452a293dcb01fab556f810',
'a1065c1a5d908796745e9c5be297ea2d402859dc',
'05ddb03cd423042ee6af3a14b6c4c0772eb75757',
'3c0c8e162bb8d42348beb6f4527f303c7487ce96',
'df8543eaddb005dab92ef0cdab7c19b41ef647f8',
'75e87b5ff18b2c53688e43a2e599fd6b3ab06d92',
'268d4e63b8fb38d37556384549717531e50eb65f',
'f4cb5107f1b9755ce0e8f7a7f85f5536fd204019',
'38e866dd44dce667dd19652e28324b6110e808bd',
'218651ac5b575c3f9642c2e9a5928aa22fab8483',
'472af2b122c23bf0ca10c78d389a5a7f030a3536',
'520cab82bb5bcfd8abd2301b648aafe0555044c4',
'b49972eed626571914116bae4446be571598dd81',
'3a4adb4ff64ddcdd0f1b2a86f04d2b72da5d9c92',
'22109552d6af71d392de199e21ae272009db608a',
'ccc5cb5b399bbf9d2959aafdc90233fa4ca9380d',
'849f81a20a4bb9985066d9e38f4adfba07bc5444',
'cc542c0f873470b3eb292f082771eec61c16b3d7',
'590bd7609edf9ea8dab0b5fbc38393a870b329de',
'41c11e48c3a64484b38a2d64ab3b9453bae05a14',
'e468a7947c497b435bdf1a50cf0f73abf849c79b',
'a5c4975199bfe820bd0076bb5b7c68be93ba7bf8',
'f38bf87c73ac188fc60a2bfa5bba1c838148a8a1',
'a1e3e694b147767efcab214f099a1488726abd0f',
'aaa153236b7676899572760482951d3edad7a8b5',
'25be1b61ce1f9dcc498c64a5a753efb96df3ae4c',
'39bb0e9765e0137d09dc8d41fa1dded24e1fdeed',
'5b93345c18faa20ef1f2d3f7fb5a299c27e4b66d',
'f5a605c29af773c9f5604c8f5546c991d24d2dc2',
'db99f1ef9b630fc16deb23d8c7d7df2441bc80e5',
'c226cb69f2a017712cc94493f51d7726f933bcda',
'5b3b08f15ac3bbf2644f88b0615536f33a1ff1a8',
'42f81c4cfca1438371829b7ad5e7b3db54a2cddf',
'1c23dd83c6ebba6f870b1ad02f326ea730ea53a5',
'2b663679da2a7070f91945784ac167ed3ded7280',
'fd1e67da7919dc7d0fbab0c5d02ee6e12537f2ef',
'93c1078cb6d0aeab90eb0b83ec4a737ce7bcccdc',
'05d900d16d2738b0bded3ba4a60ff24adc0776f1',
'fc19e8dae2215446ade30b6bc7aa5d4b0d6627f7',
'f30ef3957c930cf2aa74361d4d229777e7ee40ef',
'964e161dd92df9b160a6f7c7d1dedf216e8fed2c',
'bf4254555a5f4d3299aae8d4ffc28bbb1dfec3c6',
'50726acc45f673d6f0924a8bf030f3f07b1cd9c5',
'd535de08875cef1c49bfa2532281fa1254a8cb93',
'7935da6efb19ea558fe6b1f98f3b244b4a74794b',
'589f7878efd02dd5a0832c6e523f4914cbcfd450',
'8f7d4f9eed06c1d175ef6321fb7110183aabbb7c',
'467b32e7414308b245c6c004303a5638e0fa7bdf',
'b98cded462dfd80c682c953830e3df744cac756d',
'3df6b6fb4870b66931e91a59a5f9c013198bc310',
'c26f164336ea82a40b2186270249d2fe5571b12d',
'e53ff219a6d5d0713ddfa54f8fff7ff703e5e85f',
'fa9905d231bb1565086dcf2608ee2125bf585c01',
'c1fe1a306c4d7106d5a0bb47d3880836d9ecc2c6',
'7323ca7b92edbd195b2d7e18c91fd48b4c96a0cc',
'f9881d2380363cb7b3d316bbf2bde6c2d7089681',
'ca112215ba3abf12bd65e15f018def811b9d5938',
'bcdf6ddccab0c348d85ca52077ffbef12f94a336',
'28a15a0b532c47110297aa6f4f46bad4d72235a2',
'ad5bff008e0e270d19eaa7e211b1c821d4091b68',
'7f308945c4904ef168bbf57c86e56c8a3f836a2e',
'74fc338bbab1a1f42699165c588dc91639d0343b',
'4f3ec6a4af8fddf85a0f2933b6cabee44e74fe33',
'41a491270ec2bd6d230be4d163c719e6d46265e7',
'17e199488c301aad10861cdeb1ee5087d2c87517',
'0225b06163d58bc55c6e4f6b451c5553dc9558c7',
'f6bb18873580f645c09758fda398655ce5e3eff3',
'2933c394fa06892dbd1ce2937b4c2344e8239ef8',
'a6119a5c321b2755bffdb4919d910a18b0613842',
'86e975d05de96e0ea088ffdde9993f9247f0ee03',
'3248ac428a7c888723398a5c2535b5b95f550754',
'b1b5dbea32917b7db654dc193de98b840abdbcb5',
'004809dcd28c0cf078d65cc11a478d50cb3cba0d'
    ]
);
let SHA256Hash = dynamic(
    [
'77bdcb2a9873c4629d8675c8ce9cc8a0cf35c514e27f7a6dc2bc4b31f79dd9e2',
'f937aa71e0b1cb3f9a4d5c0e8ffa4f383b781dd878e71e4b73c1f084b4a7e6de',
'8469341f65cc42b86ef7ded04eca8a00266f34d6d2916330af1bf40fb69e26f0',
'd3ca5583c98a4ab0cc65773addd3444435eea13e70e3929629535f14dfe8b63b',
'2051f5d7c79e67a02880ca9f2fc0cdf4fa8827fc515f16baa743193c9b178ba0',
'4ce2df07fecdc7f7852c686440e3b421c159d8fc382481ce70165a77741fb2c4',
'9e170d1146efeee09f888c7b1bbfb10dec3ede9cc0b20b6b137c52dd146fd302',
'2b7a2703e77cb735fae7b90bbd5a2fa481aea1c34c3fb7bfada61cbcebb35efc',
'd0b6413c3dabe564435291b65f28119ad5a9c1fabc05ee48820f728740cb1a03',
'4be84a291b6c6a5f019c1c6b1ceff3b4bc3668d5874b1a423838a57560788158',
'79f2cd2009fe104e5ed6ad25d0ba06b10fb7c0983e88beab27e55b78cd2a5300',
'c4bb5b85710d7e78e82a57eb2ac2c8f7796972bada1ddc6af7ae6d318bc87aa3',
'a9827ea4e45194c65a3ff6cf03345b16bd24047165bd91d4595caae8488529db',
'59a4ae454be71f8a036a7b4c74ae40f4ca6e7105dabfabb4637e87b7a9afb51d',
'fe33146518676279692217e32f8c36a9749d705981e672ebbde79c80b32dd8b7',
'6e1c976151313a24fbd1f620a0a2c66aaf5489d44b8153eb12e789bfbea3731f',
'5751ac3b127f6c8cf251d995ac6254f8999ab227dd6da870f1e0249b3ce56bb6',
'964efc495e4e1a2075fcd48a661166fb8df81d81d8ac2c26768325dc15da7f70',
'd9882283ee2dc487c2a5fb97f8067051c259c4721cd4aea8c435302fe6b274c4',
'c11d6bdda1972a2f538f0daea099df17ce76077098b9f3f72459cf7db1ec5ec6',
'178dc666df641f4f1f184d54c7bcac4764e81bb1c3b03a7207b321660c77770b',
'5756a54a1d9ae74df58008048c6042e7254cc7eed0389f556db3f000cb191000',
'c828558c67601c94511720748a49703b09814bcd21be2caa98b36faa445e19db',
'a57112c53bf2ee334a6d01b39cb43ec8de42ba18ea925d55132567274b742ce6',
'6e05bebdc38c4bd34c83d2ca6b954ce84c87ed78fd0d932576593a3ad710e3c3',
'25e755c8957163376b3437ce808843c1c2598e0fb3c5f31dc958576cd5cde63e',
'8e16cd7d498eb69d7b3e079e1353e0df6eec70a845986475d7cf65a6740b4434',
'44f3c63c1f6414f2c3e602a57ba38f340287fe2acc15ff0c88dca503c67b1a0c',
'fe664bb9dc2976d6d2ccc07582b5c5eb85b896cc439a9af91db7e51b1c905bdb',
'3805caa8e426a6f7d7d3ce9c87ce188b20185b134d936a69b9d51125b1264dea',
'40db7affc23dcaf88c288d6a918b6371a45dcfa16e08543e9442d4d952a9ecc4',
'4878d5d7933e096305c70c83499b84893b6bd0dbe226e16ea90430efeb8b8593',
'faf76f9e66c7392cddbe7bcc73b00dc2ca2d8d1da6f46f5686dadc2e0a559acb',
'09b1003b673b559c3599dcb9250112bd3a602602f2836b54d5d7cdd1c4c4e6f2',
'3f1d22893c626346f8d361076bc66797d55b09a959ec0d36ec3d48048983f138',
'652d3717353df8fc3145ecc9f2c871034a58f2519bdd0c70a72a3d8c88bad48c',
'078403b4e89ff06d2fe2ed7e75428a381f83ffb708dbd01b0220767498947f0c',
'82cce26c60a5105e6caf5ac92eabb3dedcd883cd075f2056f27b0ec58aefaaa6',
'4d004d168b0bb9bed836404e850796173ac27efd8489738394a265478224cf27',
'6652e27ad1bf5002665b2d0821e75092a087103408560682295f90706a3289cb',
'b051ee189faf36e2d6c382fede530e9274b42bc9c42e210b4ee1bc84b0419ba6',
'0340043481091d92dcfb2c498aad3c0afca2fd208ef896f65af790cc147f8891',
'bfe88e7986fbf27db90f18959a0b1e237b6f0395fa11b9eb386e5bac143c1d2d',
'7404a08ecc0aa0d84f039d078ad39804856206ae58dde360238d4a1943557333',
'efb533249f71ea6ebfb6418bb67c94e8fbd5f2a26cbd82ef8ec1d30c0c90c6c1',
'73233ca7230fb5848e220723caa06d795a14c0f1f42c6a59482e812bfb8c217f',
'9a84cb10b7ba0b96eea473900d58052511af7b235383b6a496dffab9b982d20d',
'9af4272d6cc0e926f74ccf68d0a4d056eb37059214c312ef3628bca45a7d76cf',
'b262d0c81ac5a13c1a6aa650d1ca7b04117f654a2a97bfe7ac4a7ca8ae9a6ed5',
'432010e6d7a42710b10464e440fa4e2df2bb387839d56a5b371727dc6c3da272',
'b58de9beaf70bfd12cd6fb372f52eff5405f96602c22034a80ef01b4f9e2ded4',
'5f0bc27c272937e3ef788c290939481137148c1c5c70dbb7d1fb13cb22e3e2c1',
'7b59090b78127381593460ccea2ea64d6c5838cd8cb0e97c5e436ae58e69cdee',
'e7046b7eac25ceb5274c815aba4384099524eacf9aed683179aa29ac5f45ede8',
'38c1cab0a8c9870f2cc7cfa5f3f782c0bb8ede94ce89a41a5e9509a79d7fdf5e',
'393cd1ecf955d6938f9a9ba65808a209e7741e2fd17baa91e4960aca799be86f',
'681b1b85a0f8a7ede2c6bf8c71ad4cb56ccc4e1bb400783c93ee9b5ab76d3da6',
'd104de2912949e598f12b2b517bdbec17896cee8305766e72bbb4e604205b2b4',
'eb7bada29bcf4c6b94f7ab710a8a6702f26845c9678826ff0dfc7494a5e8186d',
'4a5f1df73581c531e62e73fe1ab374d1d93b3846d8e6b80833fd295e0fbc23f1',
'895d49db09b64f15782073d4ff4a0fe21cd91f9b9fa9902053278799313b13b1',
'99b622046fb5e122a6f2dadad0858cdd1056582701fb0968c57ec6171dc4c0ee',
'8f79942feb0c8533ce01f867902f4a72d328681249fd474b0215e9d9b4477f67',
'948f9fc9b5979fb66e91964bb2bee0b42b7e8f6b6436188fee9fb69b676d2f42',
'356266255b6aa6ba096cd8048a6a43488ffc21845430d7d0f798fd9022879377',
'4e35c7d135bd7f55cdec68d7acf176ae84b850e927fdffb005e000fef5b35a21',
'609aa1b6ebbeb93a76898219ad470832c4dd838fb3214989841af8b90fcef695',
'5e0fb8cab745678487ac1ed99b5ec2fa2d54a65cbf0e2cb9208785200f2c2b8b',
'aa4349b6531544093c4dbc1d2a7b8680d3308cbde313a38c27cd211dd80ee9d1',
'f0a59a724ee6631b7f2ae88aa9ec7c24a82f8c912512352d93d058a928c33c70',
'1cf5710e500a423b84b51fa3afdd923fe0a8255c5817d3238175623e2ebbfad9',
'959be603c11951ead9c13efd0451ba23e743ec3019562f7715c5b0306ae70537',
'0cb570e4e5229dbe488bba92f57b5951a69335dd625aa6ada0ccb34c918613b2',
'60d3a8c8a7e8bdb67a44ad4f220e52593bf46d2ce6e8d40b6db9045c68cee413',
'71b11d28dec1dadc738c4b993dba32e3c33a85421de66120be62f3ec0ed50c3e',
'b6ef03aec5d10e371f0b06c661036d838ef55fa7dc75cf91fca3622bdefa8140',
'791cb9883187ada5274c976a2e05dc756c48eda88fabdfe2eb7e19f59f0182e5',
'1ba2ef33e69d6bc03ba02a68ecd701b1eee6a33aabd44509e3b344d0948cf9f4',
'1353ffc96e0a701fa8b3dc2835a8be6199e3c8f079663ebffb6b665750ef8af9',
'2effc706d002ebf5c18160ba1cec9f88adbc4a36a3daaf5dbacc8c0dd6ad46b6',
'd13ec5610c22bad31a47b59791b6e964d4703b4019094fd44c8151ee802db7ea',
'3ac5a8f9f2f80b7a8b5267a5cd523dd449b2de5ccb7b30e448ef0dcfc8995506',
'c0621954bd329b5cabe45e92b31053627c27fa40853beb2cce2734fa677ffd93',
'899ad5af2b4ad14fa58612dc2938598ac7e892d759659aef87e4db46d70f62bf',
'e1d466b44e0dffafe4a2d0ebade37ea5f9b6a30ccf16f59d4d2e32f9204a03f8',
'a022820a62198fa3e3b89749b38db1cc3a09136524682fb99a3ce36652725065',
'3c9a7aa8cc4fd0538532e757a756709897c94b2653152a40993c7d0a47503980',
'6c8f967b12cf84eed7b8c039e04614e50cd7fcd8ca9e01563bb6f5f0a11dcb8c',
'bb4229d4fe06209fc7c8ed44da8f353dcb980b5f1a5229c7e1f17b772ff8fd8c',
'e2f7afedf6dbeaeae60a1434a8735acd426087fd16689b29b869ebe88cdbef85',
'504be292cf783ce6cb0c356034e69b76a465ec534386a776663810266d64da33',
'42389f51dc60590c2daab696e8782c3f4dd9f9a4c98a3b987e10d43174deba38',
'eec42b1fb5275eaf3e0229db99421e2b16a3c82bb64da3305662622dc2d6e07a',
'33b8b7198b8e9a24b415d280d673cfa4efe4d249ac9e21703a61c65dc0933d74',
'c91e8e5c2491f7708c4e550c18acab121e1b245ade7b2abb79cdd25b8a9cf379',
'b292ae784ab91b99cc2b8f5cc173813cdb52fb75c6dab85bd1ce05a244b85fca',
'629c0a325f24016534ebc2e0578068593ca883557f8c10cc1ae4d5b0ab91bfec',
'bc6d23e865cdbc4d57451e80797be2b2feff531ca2743c533e5d114c3a19433d',
'7b1e06cf7c362e62b156652b069a4ca1800e0ab72730636f64cc24dabd3830a8',
'cc9da7fce451e409a4d994b4675db6a3651a551b9a004461d14a3d3532765d84'
    ]
);
DeviceFileEvents
| where SHA1 in(SHA1Hash) or SHA256 in(SHA256Hash) or MD5 in(MD5Hash)
| union DeviceImageLoadEvents
| where SHA1 in(SHA1Hash) or SHA256 in(SHA256Hash) or MD5 in(MD5Hash)
```

## Category

This query can be used to detect the following attack techniques and tactics ([see MITRE ATT&CK framework](https://attack.mitre.org/)) or security configuration states.
| Technique, tactic, or state | Covered? (v=yes) | Notes |
|------------------------|----------|-------|
| Initial access |  |  |
| Execution |  |  |
| Persistence |  |  |
| Privilege escalation | v |  |
| Defense evasion |  |  |
| Credential Access |  |  |
| Discovery |  |  |
| Lateral movement |  |  |
| Collection |  |  |
| Command and control |  |  |
| Exfiltration |  |  |
| Impact |  |  |
| Vulnerability | v |  |
| Misconfiguration |  |  |
| Malware, component |  |  |

## See also

* [Locate Nobelium implant receiving DNS response](./c2-lookup-from-nonbrowser[Nobelium].md)
* [Locate Nobelium implant receiving DNS response](./c2-lookup-response[Nobelium].md)
* [Compromised certificate [Nobelium]](./compromised-certificate[Nobelium].md)
* [FireEye Red Team tool CVEs [Nobelium]](./fireeye-red-team-tools-CVEs%20[Nobelium].md)
* [View data on software identified as affected by Nobelium campaign](./known-affected-software-orion[Nobelium].md)
* [Locate SolarWinds processes launching suspicious PowerShell commands](./launching-base64-powershell[Nobelium].md)
* [Locate SolarWinds processes launching command prompt with the echo command](./launching-cmd-echo[Nobelium].md)
* [Locate Nobelium-related malicious DLLs created in the system or locally](./locate-dll-created-locally[Nobelium].md)
* [Locate Nobelium-related malicious DLLs loaded in memory](./locate-dll-loaded-in-memory[Nobelium].md)
* [Get an inventory of SolarWinds Orion software possibly affected by Nobelium](./possible-affected-software-orion[Nobelium].md)
* [Anomalous use of MailItemAccess on other users' mailboxes [Nobelium]](../Collection/Anomaly%20of%20MailItemAccess%20by%20Other%20Users%20Mailbox%20[Nobelium].md)
* [Nobelium campaign DNS pattern](../Command%20and%20Control/DNSPattern%20[Nobelium].md)
* [Nobelium encoded domain in URL](../Command%20and%20Control/EncodedDomainURL%20[Nobelium].md)
* [Domain federation trust settings modified](../Defense%20evasion/ADFSDomainTrustMods[Nobelium].md)
* [Discovering potentially tampered devices [Nobelium]](../Defense%20evasion/Discovering%20potentially%20tampered%20devices%20[Nobelium].md)
* [Mail.Read or Mail.ReadWrite permissions added to OAuth application](../Defense%20evasion/MailPermissionsAddedToApplication[Nobelium].md)
* [Suspicious enumeration using Adfind tool](../Discovery/SuspiciousEnumerationUsingAdfind[Nobelium].md)
* [Anomalous use of MailItemAccess by GraphAPI [Nobelium]](../Exfiltration/Anomaly%20of%20MailItemAccess%20by%20GraphAPI%20[Nobelium].md)
* [MailItemsAccessed throttling [Nobelium]](../Exfiltration/MailItemsAccessed%20Throttling%20[Nobelium].md)
* [OAuth apps accessing user mail via GraphAPI [Nobelium]](../Exfiltration/OAuth%20Apps%20accessing%20user%20mail%20via%20GraphAPI%20[Nobelium].md)
* [OAuth apps reading mail via GraphAPI and directly [Nobelium]](../Exfiltration/OAuth%20Apps%20reading%20mail%20both%20via%20GraphAPI%20and%20directly%20[Nobelium].md)
* [OAuth apps reading mail via GraphAPI anomaly [Nobelium]](../Exfiltration/OAuth%20Apps%20reading%20mail%20via%20GraphAPI%20anomaly%20[Nobelium].md)
* [Credentials were added to an Azure AD application after 'Admin Consent' permissions granted [Nobelium]](../Persistence/CredentialsAddAfterAdminConsentedToApp[Nobelium].md)
* [New access credential added to application or service principal](../Persistence/NewAppOrServicePrincipalCredential[Nobelium].md)
* [Add uncommon credential type to application [Nobelium]](../Privilege%20escalation/Add%20uncommon%20credential%20type%20to%20application%20[Nobelium].md)
* [ServicePrincipalAddedToRole [Nobelium]](../Privilege%20escalation/ServicePrincipalAddedToRole%20[Nobelium].md)

## Contributor info

**Contributor:** Dario Brambilla
**GitHub alias:** darioongit
**Organization:** Microsoft 365 Defender
