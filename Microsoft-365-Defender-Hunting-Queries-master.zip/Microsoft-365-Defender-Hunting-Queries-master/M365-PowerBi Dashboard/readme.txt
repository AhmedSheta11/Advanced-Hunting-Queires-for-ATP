This folder contains some PowerBi dashboard that can be helpful to visualize data from Microsoft Threat Protection using the built-in APIs
