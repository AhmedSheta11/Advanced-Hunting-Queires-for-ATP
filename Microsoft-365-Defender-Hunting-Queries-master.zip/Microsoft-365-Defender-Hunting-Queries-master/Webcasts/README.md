# Webcasts

This repository will contain query files used in our public training \ webcasts for reuse within your instance of Microsoft Threat Protection

---

## Tracking the Adversary
[Signup Link](https://techcommunity.microsoft.com/t5/microsoft-threat-protection/webinar-series-unleash-the-hunter-in-you/ba-p/1509232?ranMID=24542&ranEAID=msYS1Nvjv4c&ranSiteID=msYS1Nvjv4c-_joxReUxkmQPGUkIGSbqzg&epi=msYS1Nvjv4c-_joxReUxkmQPGUkIGSbqzg&irgwc=1&OCID=AID2000142_aff_7593_1243925&tduid=(ir__inwuq92cqkkft0kikk0sohziz32xi1kvkgq9mksc00)(7593)(1243925)(msYS1Nvjv4c-_joxReUxkmQPGUkIGSbqzg)()&irclickid=_inwuq92cqkkft0kikk0sohziz32xi1kvkgq9mksc00)

This four-part series provides an introduction to advanced hunting in Microsoft Threat Protection including
- An introduction to Kusto Query Language (KQL)
- Descriptions of each table available (as of the date of the webcast)
- Examples to help maximize your hunting skills in Advanced Hunting
- An example incident triage almost exclusively using Advanced Hunting
