 This folder contains queries on Windows Defender suite block events (as well as block-audit events when in ExploitGuard audit mode).
 This includes Windows Defender Antivirus, Exploit Guard, SmartScreen, and more.
