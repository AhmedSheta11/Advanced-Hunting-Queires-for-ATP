# Suspicious Image Load related to IcedId.md

Use this query to locate suspicious load image events by rundll32.exe or regsvr32.exe, a behavior associated with IcedId, which can lead to ransomware.

## Query
```
DeviceImageLoadEvents 
| where InitiatingProcessFileName in~ ('rundll32.exe','regsvr32.exe') 
| where FileName endswith '.txt' or FileName endswith '.pdf'
```
## Category
This query can be used to detect the following attack techniques and tactics ([see MITRE ATT&CK framework](https://attack.mitre.org/)) or security configuration states.
| Technique, tactic, or state | Covered? (v=yes) | Notes |
|------------------------|----------|-------|
| Initial access |  |  |
| Execution | V |  |
| Persistence |  |  | 
| Privilege escalation |  |  |
| Defense evasion |  |  | 
| Credential Access |  |  | 
| Discovery |  |  | 
| Lateral movement |  |  | 
| Collection |  |  | 
| Command and control |  |  | 
| Exfiltration |  |  | 
| Impact |  |  |
| Vulnerability |  |  |
| Exploit |  |  |
| Misconfiguration |  |  |
| Malware, component |  |  |
| Ransomware |V |  |


## Contributor info
**Contributor:** Microsoft 365 Defender
